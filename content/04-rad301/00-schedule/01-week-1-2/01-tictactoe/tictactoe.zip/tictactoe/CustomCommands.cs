﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace tictactoe
{
    public static class CustomCommands
    {
        public static RoutedCommand NewGame = new RoutedCommand();
    }
}
