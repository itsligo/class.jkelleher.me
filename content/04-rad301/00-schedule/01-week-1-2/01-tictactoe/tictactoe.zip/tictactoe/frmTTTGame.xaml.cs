﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace tictactoe
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        tttBoard board;
        bool xTurn;

        public Window1()
        {
            InitializeComponent();
        }

        private void NewGame_Click(object sender, RoutedEventArgs e)
        {
            MenuItem mnu = (MenuItem)sender;
            initBoard(Int32.Parse((mnu.Tag.ToString())));
            xTurn = true;
        }

        private void initBoard(int rank)
        {
            Button newButton;
            board = new tttBoard(rank);
            boardGrid.Children.Clear();
            boardGrid.Rows = rank;
            for (int i=0; i<rank; i++)
                for (int j=0; j<rank; j++)
                {
                    newButton = new Button();
                    newButton.Tag = new Point(i,j);
                    newButton.Content = newButton.Tag;
                    //newButton.Click +=new RoutedEventHandler(newButton_Click);
                    boardGrid.Children.Add(newButton);
                }
        }

        private void boardGrid_Click(object sender, RoutedEventArgs e)
        {
            Button b = e.OriginalSource as Button;
            if (b == null) return;  // reject if not a Button
            
            Point p = new Point();
            p = (Point)b.Tag;       // grab Button index from Tag

            if (xTurn)      // handle play for x
            {
                b.Content = "X";
                board[(int)p.X, (int)p.Y] = tictactoe.tttBoard.boardState.x;
            }
            else
            {
                b.Content = "O";
                board[(int)p.X, (int)p.Y] = tttBoard.boardState.o;
            }
            b.IsEnabled = false;
            tttBoard.boardState result = board.testWin();
            if (result == tttBoard.boardState.x)
                MessageBox.Show("X Wins!");
            if (result == tttBoard.boardState.o)
                MessageBox.Show("O Wins!");
            xTurn = !xTurn;

        }

        private void mnuQuit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void NewGame_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            // do something
            initBoard(Int32.Parse((e.Parameter.ToString())));
            xTurn = true;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            int rank = Convert.ToInt32(((MenuItem)sender).Tag);
            MessageBox.Show(String.Format("{0} is the rank", rank));
        }

        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {

        }
    }   // end class 
}
